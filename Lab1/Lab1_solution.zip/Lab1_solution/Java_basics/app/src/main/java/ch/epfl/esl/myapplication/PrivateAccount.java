package ch.epfl.esl.myapplication;

public class PrivateAccount extends Account{

    private boolean blockCard;

    // constructor
    public PrivateAccount(String newName, int newNumber, double initialBalance, boolean limit)
    {
        super(newName, newNumber, initialBalance);
        this.blockCard = limit;
    }

    private boolean maxReached(double amount)
    {
        double currentBalance = getBalance();
        if (amount >= currentBalance/2)
        {
            blockCard = true;
            return blockCard;
        }
        else
        {
            blockCard = false;
            return blockCard;
        }
    }
    @Override
    public void withdrawal(double amount)
    {
        boolean isOk = maxReached(amount);
        double currentBalance = getBalance();
        if (isOk)
            System.out.println("The limit has been reached");
        else
            super.withdrawal(amount);
    }
}
