package ch.epfl.esl.myapplication;

public class TestClass {
    public static void main(String[] args)
    {

        Account acct1 = new Account("Bill",738924);
        Account acct2 = new Account("Sue",894730,150);
        PrivateAccount acct3 = new PrivateAccount ("Milan", 234567, 500, false);

        acct1.displayBalance();
        acct1.deposit(89.00);
        acct1.displayBalance();

        acct2.displayBalance();
        acct2.withdrawal(300);

        acct3.withdrawal(50);
        acct3.displayBalance();
        acct3.withdrawal(350);

        System.out.println(acct1.toString());
    }
}
