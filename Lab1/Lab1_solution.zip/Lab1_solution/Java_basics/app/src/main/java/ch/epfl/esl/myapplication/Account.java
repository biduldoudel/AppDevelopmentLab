package ch.epfl.esl.myapplication;

public class Account {

    private String name;
    private int number;
    private double balance;

    // set constructors

    public Account(String newName, int newNumber)
    {
        this.name = newName;
        this.number = newNumber;
    }

    public Account(String newName, int newNumber,double initialBalance)
    {
        this(newName, newNumber);
        this.balance = initialBalance;
    }

    //get values

    public String getName()
    {
        return this.name;
    }

    public int getNumber()
    {
        return this.number;
    }

    public double getBalance()
    {
        return this.balance;
    }

    // set values

    public void setName(String name)
    {
        this.name = name;
    }

    public void setNumber (int number)
    {
        this.number = number;
    }


    public void deposit(double amount)
    {
        balance += amount;
    }


    public void withdrawal(double amount)
    {
        if (balance >= amount) {
            balance -= amount;
        } else {
            System.out.println("Insufficient Funds");
        }
    }

    public void displayBalance()
    {
        System.out.println("The balance on account "
                + number + " is " + balance);
    }

}
