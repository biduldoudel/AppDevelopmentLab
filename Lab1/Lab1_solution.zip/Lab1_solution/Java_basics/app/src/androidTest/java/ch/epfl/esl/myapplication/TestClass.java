package ch.epfl.esl.myapplication;

import static org.junit.Assert.*;

public class TestClass {

}