package ch.epfl.esl.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        TextView viewById = findViewById(R.id.my_text);
        viewById.setText(R.string.my_text2);
    }

    // Here is a small explanation of the following line:
    // - private: it is not visible/accessible from other classes
    // - final: it can only be assigned once (it won't change)
    // - this: it's a reference of the current instance of the class
    final String TAG = this.getClass().getName();
    // A function printing to logcat
    private void demo_logcat()
    {
        Log.v(TAG, "Verbose");
        Log.d(TAG, "Debug");
        Log.i(TAG, "Information");
        Log.w(TAG, "Warning");
        Log.e(TAG, "Error");
    }
}
