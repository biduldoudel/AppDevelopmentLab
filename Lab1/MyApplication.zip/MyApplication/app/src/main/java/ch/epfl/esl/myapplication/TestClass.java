package ch.epfl.esl.myapplication;

public class TestClass {
    public static void main(String[] args) {
        Account acct1 = new Account();
        Account acct2 = new Account();

        acct1.name = "Bill";
        acct1.number = 738924;
        acct1.balance = 231.48;

        acct2.name = "Sue";
        acct2.number = 894730;
        acct2.balance = 0;

        acct1.displayBalance();
        acct1.deposit(89.00);
        acct1.displayBalance();

        acct2.displayBalance();
        acct2.withdrawal(300);

        System.out.println(acct1.toString());
    }
}
