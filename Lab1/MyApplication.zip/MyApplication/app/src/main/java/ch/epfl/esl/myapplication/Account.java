package ch.epfl.esl.myapplication;


class Account {

    /**
     * Name of the account holder.
     */
    String name;

    /**
     * Number of the account.
     */
    int number;

    /**
     * Current balance in the account.
     */
    double balance;

    /**
     * Deposit @a amount into the account.
     */
    public void deposit(double amount) {
        balance += amount;
    }

    /**
     * Withdraw @a amount from the account.  Prints "Insufficient
     * Funds" if there's not enough money in the account.
     */
    public void withdrawal(double amount) {
        if (balance >= amount) {
            balance -= amount;
        } else {
            System.out.println("Insufficient Funds");
        }
    }

    /**
     * Display the current @a amount in the account.
     */
    public void displayBalance() {
        System.out.println("The balance on account "
                + number + " is " + balance);
    }
}