package ch.epfl.esl.sportstracker;

import android.os.AsyncTask;

import java.util.List;

public class ReadingHeartRateAndLocationAsyncTask extends
        AsyncTask<Void, Void,
                List<SensorDataEntity>> {

    private final SportTrackerRoomDatabase db;
    private final OnTaskCompletedListener onTaskCompletedListener;

    ReadingHeartRateAndLocationAsyncTask(OnTaskCompletedListener
                                                 onTaskCompletedListener,
                                         SportTrackerRoomDatabase db) {
        this.onTaskCompletedListener = onTaskCompletedListener;
        this.db = db;
    }


    @Override
    protected List<SensorDataEntity> doInBackground(Void... voids) {
        List<SensorDataEntity> sensorDataEntityList = db.sensorDataDao()
                .getAllValues
                        (SensorDataEntity.HEART_RATE);
        db.sensorDataDao().deleteAll();
        return sensorDataEntityList;
    }

    @Override
    protected void onPostExecute(List<SensorDataEntity> hrValues) {
        super.onPostExecute(hrValues);
        RecordingActivity.hrArray = new float[hrValues.size()];
        for (int i = 0; i < hrValues.size(); i++) {
            RecordingActivity.hrArray[i] = (float) hrValues.get(i).value;
        }
        onTaskCompletedListener.onTaskCompleted();
    }
}