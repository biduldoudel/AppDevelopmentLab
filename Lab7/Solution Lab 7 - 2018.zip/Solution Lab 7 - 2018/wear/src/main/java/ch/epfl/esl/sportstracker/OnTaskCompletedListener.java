package ch.epfl.esl.sportstracker;

public interface OnTaskCompletedListener {
    void onTaskCompleted();
}
