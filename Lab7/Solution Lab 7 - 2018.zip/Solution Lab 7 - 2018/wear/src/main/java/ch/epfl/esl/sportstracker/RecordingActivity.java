package ch.epfl.esl.sportstracker;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.LocalBroadcastManager;
import android.support.wearable.activity.WearableActivity;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class RecordingActivity extends WearableActivity implements
        SensorEventListener,
        LocationListener {

    public static final String STOP_ACTIVITY = "STOP_ACTIVITY";
    private final String TAG = this.getClass().getSimpleName();
    private SportTrackerRoomDatabase sportTrackerDB;
    private List<Integer> hrList = new ArrayList<Integer>();
    protected static float[] hrArray;
    private int sizeListToSave = 10;

    private ConstraintLayout mLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recording);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission("android" + ""
                        + ".permission.BODY_SENSORS") == PackageManager
                        .PERMISSION_DENIED) {
            requestPermissions(new String[]{"android.permission" +
                    ".BODY_SENSORS"}, 0);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                (checkSelfPermission("android" + ""
                        + ".permission.ACCESS_FINE_LOCATION") == PackageManager
                        .PERMISSION_DENIED ||
                        checkSelfPermission("android.permission" +
                                ".ACCESS_COARSE_LOCATION") ==
                                PackageManager.PERMISSION_DENIED ||
                        checkSelfPermission("android" + "" +
                                ".permission.INTERNET") == PackageManager
                                .PERMISSION_DENIED)) {
            requestPermissions(new String[]{"android.permission" +
                    ".ACCESS_FINE_LOCATION", "android"
                    + ".permission.ACCESS_COARSE_LOCATION", "android" +
                    ".permission.INTERNET"}, 0);
        }

        // Create instance of Sport Tracker Room DB
        sportTrackerDB = SportTrackerRoomDatabase.getDatabase
                (getApplicationContext());

        final SensorManager sensorManager = (SensorManager) getSystemService
                (MainActivity
                        .SENSOR_SERVICE);
        Sensor hr_sensor = sensorManager.getDefaultSensor(Sensor
                .TYPE_HEART_RATE);
        sensorManager.registerListener(this, hr_sensor, SensorManager
                .SENSOR_DELAY_UI);

        // Acquire a reference to the system Location Manager
        LocationManager locationManager = (LocationManager) this
                .getSystemService(Context
                        .LOCATION_SERVICE);
        if (locationManager != null) {
            try {
                locationManager.requestLocationUpdates(LocationManager
                                .NETWORK_PROVIDER, 0, 0,
                        this);
            } catch (Exception e) {
                Log.w(TAG, "Could not request location updates");
            }
        }

        LocalBroadcastManager.getInstance(this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                sensorManager.unregisterListener(RecordingActivity.this);
                //Read HR and Location data
                OnTaskCompletedListener onTaskCompletedListener = new
                        OnTaskCompletedListener() {
                            @Override
                            public void onTaskCompleted() {
                                Intent intenSendHR = new Intent
                                        (RecordingActivity.this,
                                                WearService.class);
                                intenSendHR.setAction(WearService.ACTION_SEND
                                        .DATA_EXERCISE
                                        .name());
                                intenSendHR.putExtra(WearService.HEART_RATE_AND_LOCATION,
                                        hrArray);
                                startService(intenSendHR);
                                finish();
                            }
                        };

                ReadingHeartRateAndLocationAsyncTask hrAsyncTask = new
                        ReadingHeartRateAndLocationAsyncTask
                        (onTaskCompletedListener, sportTrackerDB);
                hrAsyncTask.execute();
            }
        }, new IntentFilter(STOP_ACTIVITY));

        mLayout = findViewById(R.id.containerRecording);
        // Enables Always-on
        setAmbientEnabled();
    }

    @Override
    public void onEnterAmbient(Bundle ambientDetails) {
        super.onEnterAmbient(ambientDetails);
        updateDisplay();
    }

    @Override
    public void onExitAmbient() {
        super.onExitAmbient();
        updateDisplay();
    }

    private void updateDisplay() {
        if (isAmbient()) {
            mLayout.setBackgroundColor(getResources().getColor(android.R
                    .color.black, getTheme()));
        } else {
            mLayout.setBackgroundColor(getResources().getColor(android.R
                    .color.white, getTheme()));
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        TextView textViewHR = findViewById(R.id.hrSensor);
        int heartRate = (int) event.values[0];
        if (textViewHR != null)
            textViewHR.setText(String.valueOf(event.values[0]));

        // Add heart rate values in a list and save in DB in chunks of
        // sizeListToSave with a specific AsyncTask
        hrList.add(heartRate);
        if (hrList.size() % sizeListToSave == 0) {
            SavingHeartRateAsyncTask hrAsyncTask = new
                    SavingHeartRateAsyncTask(sportTrackerDB);
            hrAsyncTask.execute(hrList);
            Log.d(TAG, "" + hrList);
        }

        Intent intent = new Intent(RecordingActivity.this, WearService.class);
        intent.setAction(WearService.ACTION_SEND.HEART_RATE.name());
        intent.putExtra(WearService.HEART_RATE, heartRate);
        startService(intent);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onLocationChanged(Location location) {
        double longitude = location.getLongitude();
        double latitude = location.getLatitude();

        TextView textViewLocation = findViewById(R.id.Location);
        if (textViewLocation != null)
            textViewLocation.setText("Lat: " + latitude + "\nLon: " +
                    longitude);

        Intent intent = new Intent(RecordingActivity.this, WearService.class);
        intent.setAction(WearService.ACTION_SEND.LOCATION.name());
        intent.putExtra(WearService.LONGITUDE, longitude);
        intent.putExtra(WearService.LATITUDE, latitude);
        startService(intent);
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }



}
